
# 1.1.0

Three more symbols: `neq`: ≠, `geq`: ≥, `leq`: ≤

# 1.0.0

First released version.
